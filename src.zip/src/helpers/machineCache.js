// helpers/machineCache.js
// Singleton para cachear la lista de máquinas en memoria
const machineCache = {
  machines: null,
};
export default machineCache;
